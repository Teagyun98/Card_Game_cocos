window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
        o = b;
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  AudioManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fcea7fpfvRBta7lXaue/zPn", "AudioManager");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.heart = null;
        _this.star = null;
        _this.tri = null;
        _this.square = null;
        return _this;
      }
      NewClass.prototype.PlayAudio = function(num) {
        switch (num) {
         case 1:
          cc.audioEngine.play(this.heart, false, 1);
          break;

         case 2:
          cc.audioEngine.play(this.tri, false, 1);
          break;

         case 3:
          cc.audioEngine.play(this.square, false, 1);
          break;

         case 4:
          cc.audioEngine.play(this.star, false, 1);
        }
      };
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "heart", void 0);
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "star", void 0);
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "tri", void 0);
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "square", void 0);
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ],
  Btn: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "479e3WAb5tPi7G60A2iRYF5", "Btn");
    "use strict";
    cc.Class({
      extends: cc.Component,
      properties: {},
      start: function start() {
        cc.director.preloadScene("main");
      },
      OnClickEvent: function OnClickEvent() {
        cc.director.loadScene("main");
      }
    });
    cc._RF.pop();
  }, {} ],
  Chick: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "0863fn9I/9I3K4McdSLTjIe", "Chick");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.frontChick = null;
        _this.frontCard = null;
        _this.Shape1 = null;
        _this.Shape2 = null;
        _this.Shape3 = null;
        _this.Shape4 = null;
        _this.x = null;
        _this.shapeNum = null;
        _this.GameManager = null;
        _this.Goal = false;
        _this.GameStart = false;
        _this.particle = null;
        return _this;
      }
      NewClass.prototype.start = function() {
        switch (this.shapeNum) {
         case 1:
          this.frontCard = this.Shape1;
          break;

         case 2:
          this.frontCard = this.Shape2;
          break;

         case 3:
          this.frontCard = this.Shape3;
          break;

         case 4:
          this.frontCard = this.Shape4;
        }
        this.scheduleOnce(this.firstOpen, 5);
        this.node.on("touchend", this.OpenCard, this);
      };
      NewClass.prototype.update = function(dt) {
        this.node.x = cc.lerp(this.node.x, this.x, dt);
        this.Goal && (this.node.y = cc.lerp(this.node.y, 1e3, .5 * dt));
      };
      NewClass.prototype.OpenCard = function() {
        if (this.GameStart && !this.GameManager.getComponent("GameManager").collect2 && !this.frontChick.active) {
          this.frontChick.active = true;
          this.frontCard.active = true;
          this.GameManager.getComponent("GameManager").collectCheck = true;
          this.Collect();
        }
      };
      NewClass.prototype.Collect = function() {
        if (null == this.GameManager.getComponent("GameManager").collect1) {
          this.GameManager.getComponent("GameManager").collect1 = this.node;
          this.GameManager.getComponent("GameManager").Hint();
        } else {
          this.GameManager.getComponent("GameManager").collect2 = this.node;
          this.GameManager.getComponent("GameManager").CheckGoal();
        }
      };
      NewClass.prototype.CloseCard = function() {
        this.frontChick.active = false;
        this.frontCard.active = false;
      };
      NewClass.prototype.firstOpen = function() {
        this.frontChick.active = true;
        this.frontCard.active = true;
        this.scheduleOnce(this.firstClose, 2);
      };
      NewClass.prototype.firstClose = function() {
        this.frontChick.active = false;
        this.frontCard.active = false;
        this.GameStart = true;
        this.GameManager.getComponent("GameManager").FirstHint();
      };
      NewClass.prototype.HintMove = function() {
        this.scheduleOnce(this.MoveUp, 0);
      };
      NewClass.prototype.MoveUp = function() {
        this.node.y = this.node.y + 10;
        this.scheduleOnce(this.MoveDown, 1);
      };
      NewClass.prototype.MoveDown = function() {
        this.node.y = this.node.y - 10;
      };
      NewClass.prototype.PlayParticle = function() {
        this.particle.active = true;
        this.schedule(this.StopParticle, 1);
      };
      NewClass.prototype.StopParticle = function() {
        this.particle.active = false;
      };
      __decorate([ property(cc.Node) ], NewClass.prototype, "frontChick", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "frontCard", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "Shape1", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "Shape2", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "Shape3", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "Shape4", void 0);
      __decorate([ property(cc.Float) ], NewClass.prototype, "x", void 0);
      __decorate([ property(cc.Integer) ], NewClass.prototype, "shapeNum", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "GameManager", void 0);
      __decorate([ property(cc.Boolean) ], NewClass.prototype, "Goal", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "particle", void 0);
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ],
  GameManager: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "f8785UeY/JMRo41SQjYMFZb", "GameManager");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.ChickArr = [];
        _this.temp = null;
        _this.collect1 = null;
        _this.collect2 = null;
        _this.GoalCount = 0;
        _this.collectCheck = false;
        _this.ending = null;
        return _this;
      }
      NewClass.prototype.onLoad = function() {
        this.shuffleArr();
        for (var i = 1; i < 5; i++) {
          this.ChickArr[i - 1].getComponent("Chick").shapeNum = i;
          this.ChickArr[i + 3].getComponent("Chick").shapeNum = i;
        }
      };
      NewClass.prototype.shuffleArr = function() {
        var rand1, rand2;
        for (var i = 0; i < this.ChickArr.length; i++) {
          rand1 = Math.floor(Math.random() * this.ChickArr.length);
          rand2 = Math.floor(Math.random() * this.ChickArr.length);
          this.temp = this.ChickArr[rand1];
          this.ChickArr[rand1] = this.ChickArr[rand2];
          this.ChickArr[rand2] = this.temp;
        }
      };
      NewClass.prototype.CheckGoal = function() {
        if (null != this.collect2) if (this.collect1.getComponent("Chick").shapeNum == this.collect2.getComponent("Chick").shapeNum) {
          this.node.getComponent("AudioManager").PlayAudio(this.collect1.getComponent("Chick").shapeNum);
          this.collect1.getComponent("Chick").Goal = true;
          this.collect2.getComponent("Chick").Goal = true;
          this.collect1.getComponent("Chick").PlayParticle();
          this.collect2.getComponent("Chick").PlayParticle();
          this.collect1 = null;
          this.collect2 = null;
          this.GoalCount++;
          4 == this.GoalCount && this.GameClear();
        } else this.scheduleOnce(this.CloseOrder, 1);
      };
      NewClass.prototype.CloseOrder = function() {
        this.collect1.getComponent("Chick").CloseCard();
        this.collect2.getComponent("Chick").CloseCard();
        this.collect1 = null;
        this.collect2 = null;
      };
      NewClass.prototype.FirstHint = function() {
        this.scheduleOnce(this.FirstHintGo, 5);
      };
      NewClass.prototype.FirstHintGo = function() {
        if (!this.collectCheck) for (var i = 0; i < this.ChickArr.length; i++) 1 == this.ChickArr[i].getComponent("Chick").shapeNum && this.ChickArr[i].getComponent("Chick").HintMove();
      };
      NewClass.prototype.GameClear = function() {
        this.ending.active = true;
      };
      NewClass.prototype.Hint = function() {
        this.unschedule(this.HintGo);
        this.schedule(this.HintGo, 5);
      };
      NewClass.prototype.HintGo = function() {
        for (var i = 0; i < this.ChickArr.length; i++) this.ChickArr[i].getComponent("Chick").shapeNum != this.collect1.getComponent("Chick").shapeNum || this.ChickArr[i].getComponent("Chick").frontCard.active || this.ChickArr[i].getComponent("Chick").HintMove();
      };
      __decorate([ property(cc.Node) ], NewClass.prototype, "ChickArr", void 0);
      __decorate([ property(cc.Node) ], NewClass.prototype, "ending", void 0);
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ],
  "Return Btn": [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "223e0JBveVIrZtgovuSymsy", "Return Btn");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      NewClass.prototype.start = function() {
        cc.director.preloadScene("Title");
      };
      NewClass.prototype.OnClickEvent = function() {
        cc.director.loadScene("Title");
      };
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ],
  TitleAudio: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fea82WZpAdNKY85pL4AzqaT", "TitleAudio");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.flipflip = null;
        _this.weGo = null;
        return _this;
      }
      NewClass.prototype.start = function() {
        cc.audioEngine.play(this.flipflip, false, 1);
        this.scheduleOnce(this.weGoPlay, 2);
      };
      NewClass.prototype.weGoPlay = function() {
        cc.audioEngine.play(this.weGo, false, 1);
      };
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "flipflip", void 0);
      __decorate([ property(cc.AudioClip) ], NewClass.prototype, "weGo", void 0);
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ],
  WaveFlower: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "6bbe8KwjFBAf4KOnlnk/jjV", "WaveFlower");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var NewClass = function(_super) {
      __extends(NewClass, _super);
      function NewClass() {
        return null !== _super && _super.apply(this, arguments) || this;
      }
      NewClass.prototype.start = function() {
        this.WaveRight();
      };
      NewClass.prototype.WaveRight = function() {
        this.node.position.x += 10;
        this.scheduleOnce(this.WaveLeft, 1);
      };
      NewClass.prototype.WaveLeft = function() {
        this.node.position.x -= 10;
        this.scheduleOnce(this.WaveLeft2, 1);
      };
      NewClass.prototype.WaveLeft2 = function() {
        this.node.position.x -= 10;
        this.scheduleOnce(this.WaveRight2, 1);
      };
      NewClass.prototype.WaveRight2 = function() {
        this.node.position.x += 10;
        this.scheduleOnce(this.WaveRight, 1);
      };
      NewClass = __decorate([ ccclass ], NewClass);
      return NewClass;
    }(cc.Component);
    exports.default = NewClass;
    cc._RF.pop();
  }, {} ]
}, {}, [ "AudioManager", "Btn", "Chick", "GameManager", "Return Btn", "TitleAudio", "WaveFlower" ]);
//# sourceMappingURL=index.js.map
