window._CCSettings = {
    platform: "win32",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    hasResourcesBundle: false,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/scene/Title.fire",
    orientation: "",
    server: "",
    debug: true,
    jsList: [],
    bundleVers: {
        internal: "a6cf7",
        main: "c85f9"
    }
};
